import os
import sys
import json
import time
import ssl
import threading
import logging
import platform
import certifi
import urllib3
import asyncio
import re
from datetime import datetime, timedelta, time as dt_time
from functools import partial
import warnings
import getpass
from zoneinfo import ZoneInfo
from telethon.sessions import StringSession
from urllib.parse import urlparse

try:
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich.style import Style
    from rich.panel import Panel
    from colorama import Fore, Style as ColoramaStyle, init
    from telethon import TelegramClient, events
    from telethon.errors import SessionPasswordNeededError
    import pyfiglet
except ImportError as e:
    print(f"Error: A required library is missing. Please install it.")
    print(f"Missing module: {e.name}")
    print("You can install all required packages by running:")
    print("pip install rich colorama telethon pyfiglet")
    sys.exit(1)

init(autoreset=True)
console = Console()
warnings.filterwarnings("ignore", category=DeprecationWarning)

STYLE_TRADE_NEW_HEADER = Style(color="cyan", bold=True)
STYLE_TRADE_RESULT_HEADER = Style(color="magenta", bold=True)
STYLE_ACCOUNT_NAME_HEADER = Style(color="yellow", bold=True)
STYLE_FIELD_NAME = Style(bold=True)
STYLE_VALUE_GREEN = Style(color="green")
STYLE_VALUE_CYAN = Style(color="cyan")
STYLE_VALUE_RED = Style(color="red")
STYLE_VALUE_YELLOW = Style(color="yellow")
STYLE_VALUE_WHITE = Style(color="white")
STYLE_SEPARATOR = Style(color="blue")
STYLE_TABLE_HEADER = Style(color="magenta", bold=True)
STYLE_INFO_HEADER = Style(color="magenta", bold=True)
STYLE_INFO_FIELD = Style(color="cyan")
STYLE_INFO_VALUE = Style(color="white")
STYLE_INFO_MSG = Style(color="white")
STYLE_SUCCESS_MSG = Style(color="green")
STYLE_WARNING_MSG = Style(color="yellow")
STYLE_ERROR_MSG = Style(color="red")
STYLE_CONNECTION_INFO = Style(color="cyan", dim=True)
STYLE_HEADER = Style(color="cyan", bold=True)
STYLE_SUCCESS = Style(color="green", bold=True)
STYLE_ERROR = Style(color="red", bold=True)
STYLE_WARNING = Style(color="yellow", bold=True)
STYLE_INFO = Style(color="blue", bold=True)
STYLE_INPUT = Style(color="magenta", bold=True)
SESSIONS_FILE = "sessions.json"

urllib3.disable_warnings()
root_logger = logging.getLogger(__name__)
root_logger.setLevel(logging.INFO)
stdout_handler = logging.StreamHandler(sys.stdout)
for handler in logging.root.handlers[:]:
    logging.root.removeHandler(handler)
logging.root.addHandler(logging.NullHandler())
logging.root.setLevel(logging.CRITICAL + 1)
ws_logger = logging.getLogger("websocket")
for logger_name_to_silence in ["websocket", "urllib3"]:
    lib_logger = logging.getLogger(logger_name_to_silence)
    lib_logger.handlers = []
    lib_logger.addHandler(logging.NullHandler())
    lib_logger.propagate = False
    lib_logger.setLevel(logging.CRITICAL + 1)
cert_path = certifi.where()
os.environ['SSL_CERT_FILE'] = cert_path
os.environ['WEBSOCKET_CLIENT_CA_BUNDLE'] = cert_path
cacert = os.environ.get('WEBSOCKET_CLIENT_CA_BUNDLE')
ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
ssl_context.options |= ssl.OP_NO_TLSv1 | ssl.OP_NO_TLSv1_1 | ssl.OP_NO_TLSv1_2
ssl_context.minimum_version = ssl.TLSVersion.TLSv1_3
ssl_context.load_verify_locations(cert_path)
import websocket
import socket
from niquests import Session
from niquests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from bs4 import BeautifulSoup
logger = logging.getLogger("Browser")
logger.setLevel(logging.DEBUG)
handler = logging.StreamHandler()
handler.setFormatter(logging.Formatter("[%(levelname)s] %(message)s"))
if not logger.handlers:
    logger.addHandler(handler)
retry_strategy = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504, 104],
    allowed_methods=["HEAD", "POST", "PUT", "GET", "OPTIONS"]
)
g_account_context = None
g_buy_id = None
g_buy_successful = None

USER_EMAIL = ""
USER_PASSWORD = ""
SOURCE_ACCOUNT_TYPE = 1
TRADE_AMOUNT = 1.0
MIN_PAYOUT = 70
USE_MTG = False
MTG_MULTIPLIER = 2.0
MTG_MAX_LEVELS = 2
g_event_loop = None
mtg_state = {}

def create_cipher_suite_adapter(ssl_context=None, cipher_suite=None, source_address=None,
                               server_hostname=None, ecdh_curve='prime256v1'):
    class CipherSuiteAdapter(HTTPAdapter):
        def __init__(self, *args, **kwargs):
            self.ssl_context = ssl_context
            self.cipher_suite = cipher_suite
            self.source_address = source_address
            self.server_hostname = server_hostname
            self.ecdh_curve = ecdh_curve
            if self.source_address:
                if isinstance(self.source_address, str):
                    self.source_address = (self.source_address, 0)
                if not isinstance(self.source_address, tuple):
                    raise TypeError("source_address deve ser uma string IP ou tupla (ip, porta)")
            if not self.ssl_context:
                self.ssl_context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
                self.ssl_context.orig_wrap_socket = self.ssl_context.wrap_socket
                self.ssl_context.wrap_socket = self._wrap_socket_with_hostname
                if self.server_hostname:
                    self.ssl_context.server_hostname = self.server_hostname
                    self.ssl_context.check_hostname = False
                else:
                    self.ssl_context.check_hostname = True
                if self.cipher_suite:
                    try:
                        self.ssl_context.set_ciphers(self.cipher_suite)
                    except ssl.SSLError as e:
                        logger.warning(f"Failed to set ciphers '{self.cipher_suite}': {e}. Using default ciphers.")
                try:
                    self.ssl_context.set_ecdh_curve(self.ecdh_curve)
                except ssl.SSLError as e:
                    logger.warning(f"Failed to set ECDH curve '{self.ecdh_curve}': {e}. Using default curve.")
                except AttributeError:
                    logger.warning("ssl.SSLContext.set_ecdh_curve not available. Using default curve.")
                try:
                    self.ssl_context.minimum_version = ssl.TLSVersion.TLSv1_2
                except AttributeError:
                    logger.warning("ssl.TLSVersion not available, cannot set minimum_version.")
                try:
                    self.ssl_context.maximum_version = ssl.TLSVersion.TLSv1_3
                except AttributeError:
                    logger.warning("ssl.TLSVersion not available, cannot set maximum_version.")
            super().__init__(*args, **kwargs)

        def _wrap_socket_with_hostname(self, sock, server_hostname=None, **kwargs):
            final_hostname = server_hostname if server_hostname is not None else getattr(self.ssl_context, 'server_hostname', None)
            if final_hostname:
                self.ssl_context.check_hostname = False
                kwargs['server_hostname'] = final_hostname
            else:
                self.ssl_context.check_hostname = True
            return self.ssl_context.orig_wrap_socket(sock, **kwargs)

        def init_poolmanager(self, *args, **kwargs):
            kwargs['ssl_context'] = self.ssl_context
            kwargs['source_address'] = self.source_address
            if self.server_hostname:
                kwargs['server_hostname'] = self.server_hostname
            return super().init_poolmanager(*args, **kwargs)

        def proxy_manager_for(self, *args, **kwargs):
            kwargs['ssl_context'] = self.ssl_context
            kwargs['source_address'] = self.source_address
            if self.server_hostname:
                kwargs['server_hostname'] = self.server_hostname
            return super().proxy_manager_for(*args, **kwargs)
    return CipherSuiteAdapter()

def create_session(ecdh_curve='prime256v1', cipher_suite='HIGH:!aNULL:!MD5', source_address=None,
                  server_hostname=None, ssl_context=None, proxies=None, debug=False):
    session = Session()
    default_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                     " AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
    session.headers.update(default_headers)
    if debug:
        logger.setLevel(logging.DEBUG)
    else:
        logger.setLevel(logging.INFO)
    adapter = create_cipher_suite_adapter(
        ssl_context=ssl_context,
        cipher_suite=cipher_suite,
        source_address=source_address,
        server_hostname=server_hostname,
        ecdh_curve=ecdh_curve
    )
    adapter.max_retries = retry_strategy
    session.mount('https://', adapter)
    return session

def get_cookies_string(session):
    return '; '.join(f'{cookie.name}={cookie.value}' for cookie in session.cookies)

def get_soup_from_response(response):
    if not response:
        raise RuntimeError("No response provided.")
    return BeautifulSoup(response.text, "html.parser")

def get_json_from_response(response):
    if not response:
        raise RuntimeError("No response provided.")
    try:
        return response.json()
    except json.JSONDecodeError:
        logger.error("Failed to decode JSON from response.")
        return None
    except Exception as e:
        logger.error(f"An error occurred while getting JSON: {e}")
        return None

def send_request(session, method, url, headers=None, proxies=None, **kwargs):
    merged_headers = session.headers.copy()
    if headers:
        merged_headers.update(headers)
    if proxies:
        kwargs['proxies'] = proxies
    try:
        response = session.request(
            method,
            url,
            headers=merged_headers,
            timeout=30,
            allow_redirects=True,
            **kwargs
        )
        response.raise_for_status()
        return response
    except Exception as e:
        logger.error(f"Request failed for {method} {url}: {e}")
        return None

def get_csrf_token(session, base_url, lang='en'):
    full_url = f"https://{base_url}/{lang}"
    headers = {
        "Connection": "keep-alive",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": f"{lang},{lang.split('-')[0]};q=0.9,en-US;q=0.8,en;q=0.7",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "Referer": f"{full_url}/sign-in",
        "Upgrade-Insecure-Requests": "1",
        "Sec-Ch-Ua-Mobile": "?0",
        "Sec-Ch-Ua-Platform": '"Linux"',
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-User": "?1",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Dnt": "1"
    }
    response = send_request(session, "GET", f"{full_url}/sign-in/modal/", headers=headers)
    if not response:
        return None
    html = get_soup_from_response(response)
    token_input = html.find("input", {"name": "_token"})
    return token_input.get("value") if token_input else None

async def handle_pin_verification(session, data, base_url, lang, input_message):
    full_url = f"https://{base_url}/{lang}"
    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        "Referer": f"{full_url}/sign-in/modal"
    }
    data["keep_code"] = 1
    while True:
        try:
            code = input(input_message)
            if not code.isdigit():
                print("Please enter a valid numeric code.")
                continue
            data["code"] = code
            break
        except KeyboardInterrupt:
            print("\nClosing program due to user interrupt.")
            sys.exit(1)
    await asyncio.sleep(0.0005)
    response = send_request(session, "POST", f"{full_url}/sign-in/modal", headers=headers, data=data)
    if response and is_login_successful(response):
        return True
    else:
        html = get_soup_from_response(response)
        error_element = (html.find("div", {"class": "hint--danger"}) or
                        html.find("div", {"class": "input-control-cabinet__hint"}) or
                        html.find("div", class_=lambda x: x and ("auth__pin-error" in x or "auth__error" in x)))
        error_message = error_element.text.strip() if error_element else "Unknown error after PIN submission."
        print(f"PIN submission failed: {error_message}")
        return await handle_pin_verification(session, data, base_url, lang, input_message)

def get_profile_data(session, base_url, lang='en'):
    full_url = f"https://{base_url}/{lang}"
    response = send_request(session, "GET", f"{full_url}/trade")
    if not response or not response.ok:
        return None, None, None, None
    html = get_soup_from_response(response)
    script_tags = html.find_all("script", {"type": "text/javascript"})
    settings_script = None
    for script in script_tags:
        script_text = script.get_text()
        if "window.settings =" in script_text:
            settings_script = script_text
            break
    settings_data = {}
    if settings_script:
        try:
            match = re.search(r"window\.settings\s*=\s*(\{.*\});", settings_script, re.DOTALL)
            if match:
                json_str = match.group(1)
                settings_data = json.loads(json_str)
        except (json.JSONDecodeError, Exception):
            pass
    cookies_str = get_cookies_string(session)
    ssid = settings_data.get("token")
    user_agent = session.headers.get("User-Agent")
    return settings_data, ssid, cookies_str, user_agent

def is_login_successful(response):
    if not response:
        return False, "No response to check for login success."
    if "trade" in response.url.split('/')[-1]:
        return True, "Login successful."
    html = get_soup_from_response(response)
    error_element = (html.find("div", {"class": "hint--danger"}) or
                    html.find("div", {"class": "input-control-cabinet__hint"}) or
                    html.find("div", class_=lambda x: x and ("auth__error" in x or "login-error" in x)))
    error_message = error_element.text.strip() if error_element else "Unknown login error."
    return False, f"Login failed. {error_message}"

async def perform_login(session, username, password, base_url='market-qx.pro', lang='en'):
    full_url = f"https://{base_url}/{lang}"
    token = get_csrf_token(session, base_url, lang)
    if not token:
        return False, "Failed to retrieve CSRF token.", None, None, None
    data = {
        "_token": token,
        "email": username,
        "password": password,
        "remember": 1,
    }
    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        "Referer": f"{full_url}/sign-in/"
    }
    response = send_request(session, "POST", f"{full_url}/sign-in/", headers=headers, data=data)
    if not response:
        return False, "Login request failed.", None, None, None
    success, msg = is_login_successful(response)
    if success:
        pass
    else:
        html = get_soup_from_response(response)
        keep_code_input = html.find("input", {"name": "keep_code"})
        if keep_code_input:
            auth_body = html.find("main", {"class": "auth__body"})
            input_message = (
                f'{auth_body.find("p").text.strip()}: ' if auth_body and auth_body.find("p")
                else "Enter the PIN code we just sent to your email: "
            )
            pin_success = await handle_pin_verification(session, data, base_url, lang, input_message)
            if not pin_success:
                return False, "PIN verification failed.", None, None, None
            success, msg = True, "Login successful after PIN verification."
        else:
            return False, msg, None, None, None
    if success:
        settings_data, ssid, cookies_str, user_agent = get_profile_data(session, base_url, lang)
        if ssid and cookies_str:
            return True, msg, ssid, cookies_str, user_agent
        else:
            return False, "Login successful, but failed to retrieve session data.", None, None, None
    else:
        return False, msg, None, None, None

async def quotex_login(username, password, lang='en', debug=False):
    base_url = 'market-qx.pro'
    session = create_session(debug=debug)
    try:
        status, message, session_token, session_cookies, user_agent = await perform_login(
            session, username, password, base_url, lang
        )
        return {
            'success': status,
            'message': message,
            'session_token': session_token,
            'session_cookies': session_cookies,
            'user_agent': user_agent,
            'session': session if status else None
        }
    except Exception as e:
        session.close()
        return {
            'success': False,
            'message': f"Login process failed: {e}",
            'session_token': None,
            'session_cookies': None,
            'user_agent': None,
            'session': None
        }

def initialize_global_account_context(name: str, token: str, cookies: str, account_type: int = 1,
                           host: str = "market-qx.pro", user_agent: str = "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/119.0",
                           previous_context: dict = None):
    global g_account_context
    logger_instance = logging.getLogger(name)
    logger_instance.setLevel(logging.INFO)
    logger_instance.handlers = []
    logger_instance.addHandler(logging.NullHandler())
    logger_instance.propagate = False
    g_account_context = {
        "name": name, "token": token, "cookies": cookies, "account_type": account_type, "host": host,
        "user_agent": user_agent, "https_url": f"https://{host}",
        "wss_url": f"wss://ws2.{host}/socket.io/?EIO=3&transport=websocket", "ws_app": None,
        "check_websocket_if_connect": 0, "check_rejected_connection": 0, "check_accepted_connection": 0,
        "check_websocket_if_error": False, "websocket_error_reason": None, "started_listen_instruments": False,
        "current_asset": "EURUSD", "current_period": 60, "realtime_price": {}, "realtime_candles": None,
        "realtime_sentiment": {}, "signal_data": {},
        "account_balance": {"liveBalance": 0.0, "demoBalance": 0.0}, "historical_candles": {},
        "time_sync_server_timestamp": time.time(), "list_info_data": {}, "candle_v2_data": {},
        "settings_list": {}, "instruments": [], "send_lock": threading.Lock(), "logger": logger_instance,
        "open_trades_logged": {}, "next_assigned_trade_number": 1, "last_message_timestamp": time.monotonic(),
        "connection_monitor_task": None,
        "print_lock": asyncio.Lock(),
        "_temp_status": ""
    }
    if previous_context:
        g_account_context["next_assigned_trade_number"] = previous_context.get("next_assigned_trade_number", 1)
        g_account_context["open_trades_logged"] = previous_context.get("open_trades_logged", {})
        g_account_context["account_balance"] = previous_context.get("account_balance", {"liveBalance": 0.0, "demoBalance": 0.0})
        console.print(Text(f"State preserved from previous session. Next trade #: {g_account_context['next_assigned_trade_number']}", style=STYLE_INFO_MSG))

def extract_and_process_instruments():
    global g_account_context
    if not g_account_context or 'instruments' not in g_account_context or not g_account_context['instruments']:
        return []

    extracted_list = []
    for asset_info in g_account_context['instruments']:
        try:
            asset_data = {
                'name': asset_info[1],
                'is_open': bool(asset_info[14]),
                'payout_1m': int(asset_info[-9]),
                'payout_5m': int(asset_info[-8]),
                'raw': asset_info
            }
            extracted_list.append(asset_data)
        except (IndexError, TypeError, ValueError):
            continue
    return extracted_list

async def display_instrument_status(silent=False):
    global g_account_context
    if silent: return

    async with g_account_context['print_lock']:
        console.print()
        panel = Panel(Text("Received and processed updated instrument list from Quotex.", justify="center"),
                      title="[bold green]📊 Instrument Update 📊[/bold green]",
                      border_style="green")
        console.print(panel)

        extracted_data = extract_and_process_instruments()
        if not extracted_data:
            console.print("No instrument data available to display.", style=STYLE_WARNING_MSG)
            return

        extracted_data.sort(key=lambda x: (not x['is_open'], x['name']))

        table = Table(title="Asset Trading Status and Payouts", header_style="bold magenta", expand=True)
        table.add_column("Asset", style="cyan", width=15, no_wrap=True)
        table.add_column("Status", justify="center", style="bold")
        table.add_column("1-Min Payout", justify="right", style="yellow")
        table.add_column("5-Min Payout", justify="right", style="yellow")

        for asset in extracted_data:
            status_text = Text("OPEN", style="bold green") if asset['is_open'] else Text("CLOSED", style="dim red")
            payout_1m_str = f"{asset['payout_1m']}%" if asset['is_open'] else "N/A"
            payout_5m_str = f"{asset['payout_5m']}%" if asset['is_open'] else "N/A"
            table.add_row(
                asset['name'],
                status_text,
                payout_1m_str,
                payout_5m_str
            )
        console.print(table)
        console.print()

def extract_trade_data_manually(message_string: str) -> list:
    patterns = {
        'id': r'"id":"([^"]+)"', 'asset': r'"asset":"([^"]+)"', 'amount': r'"amount":([-]?\d+\.?\d*)',
        'profit': r'"profit":([-]?\d+\.?\d*)', 'profitAmount': r'"profitAmount":([-]?\d+\.?\d*)',
        'openPrice': r'"openPrice":([-]?\d+\.?\d*)', 'closePrice': r'"closePrice":([-]?\d+\.?\d*)',
        'command': r'"command":(\d+)', 'openTimestamp': r'"openTimestamp":(\d+)', 'closeTimestamp': r'"closeTimestamp":(\d+)',
        'uid': r'"uid":(\d+)', 'result': r'"result":"([^"]+)"', 'requestId': r'"requestId":("?[^"]+"?|\d+)',
        'openTime': r'"openTime":"([^"]+)"', 'closeTime': r'"closeTime":"([^"]+)"',
        'accountBalance': r'"accountBalance":([-]?\d+\.?\d*)', 'currency': r'"currency":"([^"]+)"',
        'purchaseTime': r'"purchaseTime":(\d+)', 'nickname': r'"nickname":"([^"]+)"'
    }
    all_trades_data = []
    clean_string = message_string
    if clean_string.startswith('42['):
        clean_string = clean_string[3:]
    if clean_string.startswith('[') and clean_string.endswith(']') and clean_string.count('{') == 1:
        clean_string = clean_string[1:-1]
    records = re.split(r'(?<=\}),(?=\{)', clean_string)
    for record_str in records:
        trade_data = {}
        for key, pattern in patterns.items():
            match = re.search(pattern, record_str)
            if match:
                value = match.group(1).strip('"')
                trade_data[key] = value
        if 'command' in trade_data:
            try:
                command_val = int(trade_data['command'])
                trade_data['direction'] = 'call' if command_val == 0 else ('put' if command_val == 1 else 'unknown')
            except ValueError:
                trade_data['direction'] = 'unknown_command_format'
        if trade_data and ('id' in trade_data or 'dealid' in trade_data):
            all_trades_data.append(trade_data)
    if not all_trades_data and clean_string.strip().startswith("{"):
        trade_data = {}
        for key, pattern in patterns.items():
            match = re.search(pattern, clean_string)
            if match:
                value = match.group(1).strip('"')
                trade_data[key] = value
        if 'command' in trade_data:
            try:
                command_val = int(trade_data['command'])
                trade_data['direction'] = 'call' if command_val == 0 else ('put' if command_val == 1 else 'unknown')
            except ValueError:
                trade_data['direction'] = 'unknown_command_format'
        if trade_data and ('id' in trade_data or 'dealid' in trade_data):
            all_trades_data.append(trade_data)
    return all_trades_data

def get_rich_result_style(result_str):
    if not result_str: return STYLE_VALUE_WHITE
    result_str_lower = result_str.lower()
    if result_str_lower == "win": return STYLE_VALUE_CYAN
    elif result_str_lower == "loss": return STYLE_VALUE_RED
    elif result_str_lower == "equal": return STYLE_VALUE_YELLOW
    return STYLE_VALUE_WHITE

def recalculate_result_if_needed(trade_info_dict):
    open_price_str = trade_info_dict.get('openPrice')
    close_price_str = trade_info_dict.get('closePrice')
    direction = trade_info_dict.get('direction')
    original_result_from_message = trade_info_dict.get("result")
    calculated_result_from_prices = None
    if open_price_str and close_price_str and direction and direction not in ['unknown', 'unknown_command_format']:
        try:
            open_p, close_p = float(open_price_str), float(close_price_str)
            if direction == 'call':
                if close_p > open_p: calculated_result_from_prices = "win"
                elif close_p < open_p: calculated_result_from_prices = "loss"
                else: calculated_result_from_prices = "equal"
            elif direction == 'put':
                if close_p < open_p: calculated_result_from_prices = "win"
                elif close_p > open_p: calculated_result_from_prices = "loss"
                else: calculated_result_from_prices = "equal"
        except (ValueError, TypeError): pass
    if calculated_result_from_prices:
        trade_info_dict["result"] = calculated_result_from_prices
    elif not original_result_from_message:
        profit_str = trade_info_dict.get('profitAmount', trade_info_dict.get('profit', '0.0'))
        try:
            profit_val = float(profit_str)
            if profit_val > 0: trade_info_dict["result"] = "win"
            elif profit_val < 0: trade_info_dict["result"] = "loss"
            else: trade_info_dict["result"] = "equal"
        except (ValueError, TypeError):
            if not trade_info_dict.get("result"):
                 trade_info_dict["result"] = "unknown_profit_fmt"

def log_new_trade_opened(assigned_number, trade_data):
    global g_account_context
    console.print()
    console.print(Text(f"========= NEW TRADE #{assigned_number} OPENED ({g_account_context['name']}) =========", style=STYLE_TRADE_NEW_HEADER))
    table = Table(show_header=True, header_style=STYLE_TABLE_HEADER, box=None, show_lines=False)
    table.add_column("Field", style=STYLE_FIELD_NAME, width=20)
    table.add_column("Value", style=STYLE_VALUE_WHITE)
    table.add_row("Platform ID", Text(str(trade_data.get('id')), style=STYLE_VALUE_WHITE))
    table.add_row("Asset", Text(str(trade_data.get('asset')), style=STYLE_VALUE_YELLOW))
    try:
        table.add_row("Amount", Text(f"${float(trade_data.get('amount', 0)):.2f}", style=STYLE_VALUE_YELLOW))
    except (ValueError, TypeError):
        table.add_row("Amount", Text(str(trade_data.get('amount', 'N/A')), style=STYLE_VALUE_YELLOW))
    table.add_row("Direction", Text(str(trade_data.get('direction','N/A')).upper(), style=STYLE_VALUE_WHITE))
    open_ts = trade_data.get('openTimestamp')
    open_time_str = "N/A"
    if open_ts:
        try: open_time_str = datetime.fromtimestamp(int(open_ts)).strftime('%Y-%m-%d %H:%M:%S')
        except: pass
    table.add_row("Open Time", Text(open_time_str, style=STYLE_VALUE_WHITE))
    close_ts = trade_data.get('closeTimestamp')
    exp_time_str = "N/A"
    if close_ts:
        try: exp_time_str = datetime.fromtimestamp(int(close_ts)).strftime('%Y-%m-%d %H:%M:%S')
        except: pass
    table.add_row("Expiration Time", Text(exp_time_str, style=STYLE_VALUE_WHITE))
    console.print(table)
    console.print(Text(".............................................", style=STYLE_SEPARATOR))
    console.print()

def log_trade_result(assigned_number, trade_data):
    global g_account_context
    console.print()
    console.print(Text(f"========= TRADE #{assigned_number} RESULT ({g_account_context['name']}) =========", style=STYLE_TRADE_RESULT_HEADER))
    table = Table(show_header=True, header_style=STYLE_TABLE_HEADER, box=None, show_lines=False)
    table.add_column("Field", style=STYLE_FIELD_NAME, width=20)
    table.add_column("Value", style=STYLE_VALUE_WHITE)
    table.add_row("Platform ID", Text(str(trade_data.get('id')), style=STYLE_VALUE_WHITE))
    table.add_row("Asset", Text(str(trade_data.get('asset')), style=STYLE_VALUE_YELLOW))
    result_str = str(trade_data.get('result', 'N/A'))
    table.add_row("Result", Text(result_str.upper(), style=get_rich_result_style(result_str)))
    try:
        table.add_row("Amount", Text(f"${float(trade_data.get('amount', 0)):.2f}", style=STYLE_VALUE_YELLOW))
    except (ValueError, TypeError):
        table.add_row("Amount", Text(str(trade_data.get('amount', 'N/A')), style=STYLE_VALUE_YELLOW))
    profit_amount = trade_data.get('profitAmount', trade_data.get('profit'))
    if profit_amount is not None:
        try:
            profit_val = float(profit_amount)
            profit_style = STYLE_VALUE_GREEN if profit_val > 0 else (STYLE_VALUE_RED if profit_val < 0 else STYLE_VALUE_YELLOW)
            table.add_row("Profit Amount", Text(f"${profit_val:.2f}", style=profit_style))
        except ValueError:
            table.add_row("Profit Amount", Text(str(profit_amount), style=STYLE_VALUE_WHITE))
    open_ts, close_ts = trade_data.get('openTimestamp'), trade_data.get('closeTimestamp')
    open_time_str, close_time_str = "N/A", "N/A"
    if open_ts:
        try: open_time_str = datetime.fromtimestamp(int(open_ts)).strftime('%H:%M:%S')
        except: pass
    if close_ts:
        try: close_time_str = datetime.fromtimestamp(int(close_ts)).strftime('%H:%M:%S')
        except: pass
    table.add_row("Open (Time/Price)", Text(f"{open_time_str} / {trade_data.get('openPrice','N/A')}", style=STYLE_VALUE_WHITE))
    table.add_row("Close (Time/Price)", Text(f"{close_time_str} / {trade_data.get('closePrice','N/A')}", style=STYLE_VALUE_WHITE))
    acc_balance = trade_data.get('accountBalance')
    if acc_balance is not None:
        try:
            bal_val = float(acc_balance)
            bal_key = "liveBalance" if g_account_context["account_type"] == 0 else "demoBalance"
            g_account_context["account_balance"][bal_key] = bal_val
            table.add_row("Account Balance", Text(f"${bal_val:.2f}", style=STYLE_VALUE_GREEN))
        except ValueError:
            table.add_row("Account Balance", Text(str(acc_balance), style=STYLE_VALUE_WHITE))
    console.print(table)
    console.print(Text("=============================================", style=STYLE_SEPARATOR))
    console.print()

def on_message_callback_global(ws, message):
    global g_account_context, g_buy_id, g_buy_successful, mtg_state, g_event_loop
    if not g_account_context: return
    try:
        g_account_context["last_message_timestamp"] = time.monotonic()

        is_binary = isinstance(message, bytes)
        raw_message_to_process = message

        if is_binary and message.startswith(b'\x04'):
            raw_message_to_process = message[1:]

        message_as_string = raw_message_to_process.decode('utf-8', errors='ignore') if isinstance(raw_message_to_process, bytes) else str(raw_message_to_process)

        temp_status = g_account_context.get("_temp_status", "")

        if message_as_string.startswith('451-["instruments/list"'):
            g_account_context["_temp_status"] = message_as_string
            return

        if temp_status == '451-["instruments/list",{"_placeholder":true,"num":0}]':
            g_account_context["_temp_status"] = ""
            try:
                decoded_json = json.loads(message_as_string)
                if isinstance(decoded_json, list) and len(decoded_json) > 0 and isinstance(decoded_json[0], list):
                    g_account_context['instruments'] = decoded_json
                    g_account_context["started_listen_instruments"] = True
                    return
            except (json.JSONDecodeError, IndexError, TypeError):
                 pass

        if isinstance(message, (str, bytes)):
            msg_bytes = message if isinstance(message, bytes) else message.encode('utf-8')
            if b"authorization/reject" in msg_bytes:
                g_account_context["check_rejected_connection"] = 1; return
            elif b"s_authorization" in msg_bytes:
                g_account_context["check_accepted_connection"] = 1
                g_account_context["check_rejected_connection"] = 0
        message_content_for_api = None
        if isinstance(message_as_string, str) and message_as_string.startswith('42'):
            try: message_content_for_api = json.loads(message_as_string[2:])
            except json.JSONDecodeError: pass
        elif isinstance(message_as_string, str) and message_as_string.strip().startswith('{'):
            try: message_content_for_api = json.loads(message_as_string)
            except json.JSONDecodeError: pass

        extracted_data_list = extract_trade_data_manually(message_as_string)
        if extracted_data_list:
            for trade_info_dict in extracted_data_list:
                trade_id = trade_info_dict.get("id")
                if not trade_id: continue
                is_new_trade_event, is_result_event = False, False
                current_close_price_str = trade_info_dict.get('closePrice')
                has_open_details = all(k in trade_info_dict for k in ['asset', 'openTimestamp', 'command', 'amount'])
                if current_close_price_str is not None:
                    try:
                        if float(current_close_price_str) == 0.0 and not trade_info_dict.get("result") and has_open_details:
                            is_new_trade_event = True
                    except ValueError: pass
                elif not trade_info_dict.get("result") and trade_info_dict.get("openTimestamp") and not current_close_price_str and has_open_details:
                     is_new_trade_event = True
                if trade_info_dict.get("result") in ["win", "loss", "equal"] or (current_close_price_str and current_close_price_str != "0"):
                    is_result_event = True
                    recalculate_result_if_needed(trade_info_dict)
                if is_new_trade_event and trade_id not in g_account_context["open_trades_logged"]:
                    g_buy_id, g_buy_successful = trade_id, trade_info_dict
                    assigned_num = g_account_context["next_assigned_trade_number"]
                    g_account_context["open_trades_logged"][trade_id] = {"assigned_number": assigned_num, "original_data": dict(trade_info_dict)}
                    g_account_context["next_assigned_trade_number"] += 1
                    log_new_trade_opened(assigned_num, trade_info_dict)
                elif is_result_event and trade_id in g_account_context["open_trades_logged"]:
                    logged_trade_info = g_account_context["open_trades_logged"].pop(trade_id)
                    assigned_num = logged_trade_info["assigned_number"]
                    final_trade_data_for_log = {**logged_trade_info["original_data"], **trade_info_dict}
                    recalculate_result_if_needed(final_trade_data_for_log)

                    if USE_MTG:
                        asset = final_trade_data_for_log.get('asset')
                        result = final_trade_data_for_log.get('result')

                        if asset:
                            mtg_state.setdefault(asset, {'level': 0})
                            current_level = mtg_state[asset]['level']

                            if result == "loss":
                                if current_level < MTG_MAX_LEVELS:
                                    mtg_state[asset]['level'] += 1
                                    new_level = mtg_state[asset]['level']

                                    losing_amount = float(final_trade_data_for_log.get('amount', TRADE_AMOUNT))
                                    new_amount = round(losing_amount * MTG_MULTIPLIER, 2)

                                    panel = Panel(
                                        Text(f"Level: {new_level}/{MTG_MAX_LEVELS}\nLosing Amount: ${losing_amount:.2f}\nNext Amount: ${new_amount:.2f}", justify="left"),
                                        title=f"[bold yellow]💸 MTG TRIGGERED for {asset} 💸[/bold yellow]", border_style="yellow", expand=False
                                    )
                                    console.print(panel)

                                    direction = final_trade_data_for_log.get('direction')
                                    open_ts = final_trade_data_for_log.get('openTimestamp')
                                    close_ts = final_trade_data_for_log.get('closeTimestamp')

                                    if direction and direction not in ['unknown', 'unknown_command_format'] and open_ts and close_ts:
                                        try:
                                            duration_seconds = int(close_ts) - int(open_ts)
                                            if duration_seconds > 0:
                                                console.print(Text(f"   Placing immediate MTG trade: {direction.upper()}, {duration_seconds}s...", style=STYLE_INFO_MSG))
                                                coro = buy_option_func(
                                                    amount=new_amount, source_account_type=SOURCE_ACCOUNT_TYPE,
                                                    asset=asset, direction=direction, duration=duration_seconds
                                                )
                                                if g_event_loop and g_event_loop.is_running():
                                                    asyncio.run_coroutine_threadsafe(coro, g_event_loop)
                                                else:
                                                    console.print(Text("   [Error] Could not place MTG trade: Event loop not running.", style=STYLE_ERROR_MSG))
                                            else:
                                                 console.print(Text(f"   [Warning] Could not place MTG trade: Invalid duration ({duration_seconds}s).", style=STYLE_WARNING_MSG))
                                        except (ValueError, TypeError) as e:
                                            console.print(Text(f"   [Error] Could not place MTG trade: Data issue for calculation. {e}", style=STYLE_ERROR_MSG))
                                    else:
                                        console.print(Text("   [Warning] Could not place MTG trade: Missing data (direction/timestamps).", style=STYLE_WARNING_MSG))
                                else:
                                    console.print(Text(f"🚫 Max MTG level ({MTG_MAX_LEVELS}) reached for {asset}. Resetting cycle.", style=STYLE_ERROR_MSG))
                                    mtg_state[asset]['level'] = 0

                            elif result in ["win", "equal"]:
                                if current_level > 0:
                                    console.print(Text(f"✅ MTG cycle for {asset} successful! Resetting to base amount.", style=STYLE_SUCCESS_MSG))
                                    mtg_state[asset]['level'] = 0
                    log_trade_result(assigned_num, final_trade_data_for_log)

        if message_content_for_api:
            if isinstance(message_content_for_api, dict) and (message_content_for_api.get("liveBalance") is not None or message_content_for_api.get("demoBalance") is not None):
                g_account_context["account_balance"].update(message_content_for_api)
            elif isinstance(message_content_for_api, list) and len(message_content_for_api) > 1 and isinstance(message_content_for_api[1], dict):
                msg_type, msg_payload = message_content_for_api[0], message_content_for_api[1]
                if msg_type == "balance" and (msg_payload.get("liveBalance") is not None or msg_payload.get("demoBalance") is not None):
                     g_account_context["account_balance"].update(msg_payload)
        if message_as_string == "41":
            g_account_context["check_websocket_if_connect"] = 0; return
    except Exception: pass

def on_error_callback_global(ws, error):
    global g_account_context
    if not g_account_context: return
    g_account_context["websocket_error_reason"] = str(error)
    g_account_context["check_websocket_if_error"] = True
    g_account_context["check_websocket_if_connect"] = 0

def on_open_callback_global(ws):
    global g_account_context
    if not g_account_context: return
    console.print(Text(f"[{g_account_context['name']}] WebSocket connection opened.", style=STYLE_CONNECTION_INFO))
    g_account_context["check_websocket_if_connect"] = 1
    g_account_context["check_websocket_if_error"] = False
    g_account_context["websocket_error_reason"] = None
    g_account_context["check_rejected_connection"] = 0
    g_account_context["check_accepted_connection"] = 0
    g_account_context["last_message_timestamp"] = time.monotonic()
    send_ssid_auth()
    asset_name = g_account_context.get("current_asset", "EURUSD")
    period = g_account_context.get("current_period", 60)
    initial_messages = [
        '42["tick"]', '42["indicator/list"]', '42["drawing/load"]', '42["pending/list"]',
        f'42["instruments/update",{{"asset":"{asset_name}","period":{int(period)}}}]',
        f'42["depth/follow","{asset_name}"]', '42["chart_notification/get"]',
    ]
    for msg_to_send in initial_messages:
        try: send_websocket_request(msg_to_send)
        except Exception: pass

def on_close_callback_global(ws, close_status_code, close_msg):
    global g_account_context
    if not g_account_context: return
    status_msg = f"Code: {close_status_code}, Msg: {close_msg if close_msg else 'N/A'}"
    if g_account_context.get("check_rejected_connection", 0) != 1:
        console.print(Text(f"[{g_account_context['name']}] WebSocket connection closed. {status_msg}", style=STYLE_CONNECTION_INFO))
    g_account_context["check_websocket_if_connect"] = 0

def on_ping_callback_global(ws, ping_msg): pass
def on_pong_callback_global(ws, pong_msg):
    try: send_websocket_request("2")
    except Exception: pass

def send_websocket_request(data: str):
    global g_account_context
    if not g_account_context: return
    with g_account_context["send_lock"]:
        if g_account_context.get("ws_app") and g_account_context["ws_app"].sock and g_account_context["ws_app"].sock.connected:
            try:
                g_account_context["ws_app"].send(data)
            except websocket.WebSocketConnectionClosedException:
                g_account_context["check_websocket_if_connect"] = 0
            except Exception:
                g_account_context["check_websocket_if_connect"] = 0

def send_ssid_auth():
    global g_account_context
    if not g_account_context: return
    payload = {"session": g_account_context["token"], "isDemo": g_account_context["account_type"], "tournamentId": 0}
    data = f'42["authorization",{json.dumps(payload)}]'
    send_websocket_request(data)

async def get_balance_for_account():
    global g_account_context
    if not g_account_context: return 0.0
    send_websocket_request('42["balance/get"]')
    start_wait_time = time.monotonic()
    while time.monotonic() - start_wait_time < 5:
        live_bal = g_account_context["account_balance"].get("liveBalance")
        demo_bal = g_account_context["account_balance"].get("demoBalance")
        if (live_bal is not None and live_bal > 0.0) or (demo_bal is not None and demo_bal > 0.0) or \
           (live_bal == 0.0 and g_account_context["account_type"] == 0) or \
           (demo_bal == 0.0 and g_account_context["account_type"] == 1):
            break
        await asyncio.sleep(0.0005)
    current_balance_dict = g_account_context["account_balance"]
    if current_balance_dict:
        balance_value = current_balance_dict.get("demoBalance") if g_account_context["account_type"] == 1 else current_balance_dict.get("liveBalance")
        if balance_value is not None:
            try: return float(f"{balance_value:.2f}")
            except (TypeError, ValueError): return 0.0
    return 0.0

def run_websocket_for_account():
    global g_account_context
    if not g_account_context: return

    parsed_url = urlparse(g_account_context["wss_url"])
    original_host = parsed_url.hostname
    target_url = g_account_context["wss_url"]
    sslopt_payload = {"cert_reqs": ssl.CERT_REQUIRED, "ca_certs": cacert, "ssl_context": ssl_context}

    try:
        ws_app = websocket.WebSocketApp(
            target_url,
            on_message=on_message_callback_global, on_error=on_error_callback_global,
            on_close=on_close_callback_global, on_open=on_open_callback_global,
            on_ping=on_ping_callback_global, on_pong=on_pong_callback_global,
            header={"User-Agent": g_account_context["user_agent"], "Origin": g_account_context["https_url"],
                    "Host": original_host, "Cookie": g_account_context["cookies"]},
        )
        g_account_context["ws_app"] = ws_app
        ws_app.run_forever(ping_interval=3, ping_timeout=2, ping_payload="2", sslopt=sslopt_payload, reconnect=1)
    finally: pass

async def connect_and_authenticate_account():
    global g_account_context
    if not g_account_context: return False
    g_account_context.update({
        "check_websocket_if_connect": 0,
        "check_accepted_connection": 0,
        "check_rejected_connection": 0,
        "check_websocket_if_error": False
    })
    ws_thread = threading.Thread(target=run_websocket_for_account, daemon=True)
    ws_thread.start()
    start_time, timeout_connect = time.monotonic(), 15
    while time.monotonic() - start_time < timeout_connect:
        if g_account_context.get("check_websocket_if_connect") == 1: break
        if g_account_context.get("check_websocket_if_error"): return False
        await asyncio.sleep(0.0001)
    else:
        console.print(Text("Connection attempt timed out.", style=STYLE_ERROR_MSG))
        return False
    auth_start_time, timeout_auth = time.monotonic(), 10
    while time.monotonic() - auth_start_time < timeout_auth:
        if g_account_context.get("check_accepted_connection") == 1:
            return True
        if g_account_context.get("check_rejected_connection") == 1 or g_account_context.get("check_websocket_if_connect") == 0:
            console.print(Text("Authentication failed or connection dropped.", style=STYLE_ERROR_MSG))
            return False
        await asyncio.sleep(0.0001)
    console.print(Text("Authentication timed out.", style=STYLE_ERROR_MSG))
    return False

def close_connection_for_account():
    global g_account_context
    if not g_account_context: return
    ws_app = g_account_context.get("ws_app")
    if ws_app:
        ws_app.keep_running = False
        try:
            if ws_app.sock and ws_app.sock.connected: ws_app.close()
        except Exception: pass
    g_account_context["ws_app"] = None
    g_account_context["check_websocket_if_connect"] = 0

def get_expiration_time_quotex(timestamp: int, duration: int) -> int:
    duration = max(duration, 60)
    period_in_minutes = (duration + 59) // 60
    current_dt = datetime.fromtimestamp(timestamp)
    minute_of_hour = current_dt.minute
    minutes_past_period_start = minute_of_hour % period_in_minutes
    candle_start_minute = minute_of_hour - minutes_past_period_start
    candle_start_dt = current_dt.replace(minute=candle_start_minute, second=0, microsecond=0)
    expiration_dt = candle_start_dt + timedelta(minutes=period_in_minutes)
    if (expiration_dt - current_dt).total_seconds() < 30:
        expiration_dt += timedelta(minutes=period_in_minutes)
    return int(time.mktime(expiration_dt.timetuple()))

def is_websocket_connected():
    global g_account_context
    return g_account_context.get("check_websocket_if_connect") == 1 if g_account_context else False

async def buy_option_func(amount: float, source_account_type, asset: str, direction: str, duration: int):
    global g_account_context
    request_id = int(time.time() * 1000)
    formatted_asset = re.sub(r'_OTC$', '_otc', asset, flags=re.IGNORECASE)
    if not is_websocket_connected():
        console.print(Text(f"Trade for {asset} skipped: WebSocket not connected.", style=STYLE_ERROR_MSG))
        return
    ws_app = g_account_context["ws_app"]
    g_account_context["current_asset"] = formatted_asset
    g_account_context["current_period"] = duration
    ws_app.send(f'42["instruments/update", {json.dumps({"asset": formatted_asset, "period": duration})}]')
    ws_app.send(f'42["chart_notification/get", {json.dumps({"asset": formatted_asset, "version": "1.0.0"})}]')
    ws_app.send(f'42["depth/follow", {json.dumps(formatted_asset)}]')
    if formatted_asset.endswith("_otc"):
        option_type, expiration_value_for_payload, settings_expiration_time, is_fast_option_for_settings = \
            100, duration, int(time.time()) + duration, False
    else:
        expiration = get_expiration_time_quotex(int(time.time()), duration)
        option_type, expiration_value_for_payload, settings_expiration_time, is_fast_option_for_settings = \
            1, expiration, expiration, True
    settings_payload = {
        "chartId": "graph", "settings": {"chartId": "graph", "chartType": 2, "currentExpirationTime": settings_expiration_time,
        "isFastOption": is_fast_option_for_settings, "isFastAmountOption": False, "isIndicatorsMinimized": False,
        "isIndicatorsShowing": True, "isShortBetElement": False, "chartPeriod": 4, "currentAsset": {"symbol": formatted_asset},
        "dealValue": amount, "dealPercentValue": 1, "isVisible": True, "isAutoScrolling": 1, "isOneClickTrade": True,
        "upColor": "#0FAF59", "downColor": "#FF6251"}}
    ws_app.send(f'42["settings/store",{json.dumps(settings_payload)}]')
    buy_payload = {"asset": formatted_asset, "amount": amount, "time": expiration_value_for_payload, "action": direction,
                   "isDemo": source_account_type, "tournamentId": 0, "requestId": str(request_id), "optionType": option_type}
    ws_app.send(f'42["orders/open",{json.dumps(buy_payload)}]')
    console.print(Text(f"Trade command for {asset} sent to the server.", style=STYLE_INFO_MSG))

def get_user_credentials():
    global USER_EMAIL, USER_PASSWORD, SOURCE_ACCOUNT_TYPE, TRADE_AMOUNT, MIN_PAYOUT, USE_MTG, MTG_MULTIPLIER, MTG_MAX_LEVELS
    console.print(Panel(
        Text("Please provide your Quotex and trading details.", justify="center"),
        title="[bold cyan]⚙️ Initial Configuration ⚙️[/bold cyan]",
        border_style="cyan"
    ))
    USER_EMAIL = console.input(Text(" 📧 Enter your Quotex email: ", style="cyan"))
    USER_PASSWORD = getpass.getpass(Text(" 🔑 Enter your Quotex password: ", style="cyan").__str__())
    source_account_type_str = console.input(Text(" 🏦 Account type (0 for Real, 1 for Demo) [default: 1]: ", style="cyan")).strip() or "1"
    SOURCE_ACCOUNT_TYPE = 0 if source_account_type_str == "0" else 1
    console.print(Text(f" ▶️ Account type set to: {'DEMO' if SOURCE_ACCOUNT_TYPE == 1 else 'REAL'}", style=STYLE_INFO_MSG))
    while True:
        try:
            amount_str = console.input(Text(" 💵 Enter the base trade amount: ", style="cyan")).strip()
            if not amount_str:
                console.print(Text("Trade amount cannot be empty.", style=STYLE_ERROR_MSG))
                continue
            amount_val = float(amount_str)
            if amount_val <= 0:
                console.print(Text("Trade amount must be a positive number.", style=STYLE_ERROR_MSG))
                continue
            TRADE_AMOUNT = amount_val
            break
        except ValueError:
            console.print(Text("Invalid input. Please enter a valid number for the trade amount.", style=STYLE_ERROR_MSG))

    while True:
        try:
            payout_str = console.input(Text(f" 📈 Min payout % to accept trades [default: {MIN_PAYOUT}%]: ", style="cyan")).strip() or str(MIN_PAYOUT)
            payout_val = int(payout_str)
            if not (0 <= payout_val <= 100):
                 console.print(Text("Payout must be between 0 and 100.", style=STYLE_ERROR_MSG))
                 continue
            MIN_PAYOUT = payout_val
            break
        except ValueError:
            console.print(Text("Invalid input. Please enter a valid integer.", style=STYLE_ERROR_MSG))

    use_mtg_str = console.input(Text(" 💸 Enable Martingale (MTG) on loss? (y/n) [default: n]: ", style="cyan")).strip().lower() or "n"
    if use_mtg_str == 'y':
        USE_MTG = True
        console.print(Text("Martingale enabled.", style=STYLE_INFO_MSG))
        while True:
            try:
                multiplier_str = console.input(Text(f"     multiplier (e.g., 2.0) [default: {MTG_MULTIPLIER}]: ", style="cyan")).strip() or str(MTG_MULTIPLIER)
                multiplier_val = float(multiplier_str)
                if multiplier_val <= 1.0:
                    console.print(Text("Multiplier must be greater than 1.0.", style=STYLE_ERROR_MSG))
                    continue
                MTG_MULTIPLIER = multiplier_val
                break
            except ValueError:
                console.print(Text("Invalid input. Please enter a valid number.", style=STYLE_ERROR_MSG))

        while True:
            try:
                levels_str = console.input(Text(f"    max levels (e.g., 2) [default: {MTG_MAX_LEVELS}]: ", style="cyan")).strip() or str(MTG_MAX_LEVELS)
                levels_val = int(levels_str)
                if levels_val < 1:
                    console.print(Text("Max levels must be at least 1.", style=STYLE_ERROR_MSG))
                    continue
                MTG_MAX_LEVELS = levels_val
                break
            except ValueError:
                console.print(Text("Invalid input. Please enter a valid integer.", style=STYLE_ERROR_MSG))

        console.print(Text(f"MTG configured: Multiplier={MTG_MULTIPLIER}, Max Levels={MTG_MAX_LEVELS}", style=STYLE_SUCCESS))
    else:
        USE_MTG = False
        console.print(Text("Martingale is disabled.", style=STYLE_INFO_MSG))

async def check_internet_connection():
    try:
        reader, writer = await asyncio.wait_for(asyncio.open_connection('8.8.8.8', 53), timeout=3)
        writer.close()
        await writer.wait_closed()
        return True
    except (OSError, asyncio.TimeoutError):
        return False

async def connection_monitor():
    global g_account_context
    LIVENESS_TIMEOUT_SECONDS, CHECK_INTERVAL_SECONDS = 5, 3
    if g_account_context:
        console.print(Text(f"[{g_account_context['name']}] Liveness monitor started. (Timeout: {LIVENESS_TIMEOUT_SECONDS}s)", style=STYLE_CONNECTION_INFO))
    while True:
        try:
            await asyncio.sleep(CHECK_INTERVAL_SECONDS)
            if not g_account_context or not is_websocket_connected():
                break
            time_since_last_message = time.monotonic() - g_account_context.get("last_message_timestamp", 0)
            if time_since_last_message > LIVENESS_TIMEOUT_SECONDS:
                console.print(Text(f"\n[{g_account_context['name']}] No data for {int(time_since_last_message)}s. Connection is stale.", style=STYLE_WARNING_MSG))
                g_account_context["check_websocket_if_connect"] = 0
                break
        except asyncio.CancelledError:
            break
        except Exception:
            break

async def run_quotex_connection():
    global g_account_context, USER_EMAIL, USER_PASSWORD
    while not g_account_context:
        console.print("\nAttempting initial login...", style=STYLE_INFO_MSG)
        login_result = await quotex_login(USER_EMAIL, USER_PASSWORD, lang='en', debug=False)
        if not login_result['success']:
            console.print(Text(f"Login failed: {login_result['message']}", style=STYLE_ERROR_MSG))
            get_user_credentials()
            if login_result.get('session'):
                login_result['session'].close()
            await asyncio.sleep(0.01)
            continue
        console.print(Text("Login successful.", style=STYLE_SUCCESS_MSG))
        initialize_global_account_context(
            name="Monitored_Account", token=login_result['session_token'], cookies=login_result['session_cookies'],
            account_type=SOURCE_ACCOUNT_TYPE
        )
        if login_result.get('session'):
            login_result['session'].close()
    while True:
        if not is_websocket_connected():
            console.print(Text("\nConnection lost or uninitialized. Starting reconnect sequence...", style=STYLE_WARNING_MSG))
            if g_account_context.get("connection_monitor_task"):
                g_account_context["connection_monitor_task"].cancel()
            close_connection_for_account()
            console.print(Text("Attempting quick reconnect with existing session...", style=STYLE_INFO_MSG))
            if await connect_and_authenticate_account():
                console.print(Text("Quick reconnect successful!", style=STYLE_SUCCESS_MSG))
            else:
                console.print(Text("Quick reconnect failed.", style=STYLE_ERROR_MSG))
                console.print(Text("Checking internet connection...", style=STYLE_INFO_MSG))
                if not await check_internet_connection():
                    console.print(Text("No internet connection. Waiting...", style=STYLE_WARNING_MSG), end="")
                    while not await check_internet_connection():
                        console.print(Text(".", style=STYLE_WARNING_MSG), end="")
                        await asyncio.sleep(0.0001)
                    console.print(Text("\nInternet connection restored!", style=STYLE_SUCCESS_MSG))
                console.print(Text("Retrying quick reconnect...", style=STYLE_INFO_MSG))
                if await connect_and_authenticate_account():
                    console.print(Text("Quick reconnect successful on retry!", style=STYLE_SUCCESS_MSG))
                else:
                    console.print(Text("Retry failed. Proceeding to full re-login.", style=STYLE_ERROR_MSG))
                    while True:
                        console.print(Text("Performing full re-login...", style=STYLE_INFO_MSG))
                        login_result = await quotex_login(USER_EMAIL, USER_PASSWORD, lang='en')
                        if login_result['success']:
                            console.print(Text("New login successful. Got new session.", style=STYLE_SUCCESS_MSG))
                            previous_context = g_account_context.copy()
                            initialize_global_account_context(
                                name="Monitored_Account", token=login_result['session_token'],
                                cookies=login_result['session_cookies'], account_type=SOURCE_ACCOUNT_TYPE,
                                previous_context=previous_context
                            )
                            if login_result.get('session'):
                                login_result['session'].close()
                            if await connect_and_authenticate_account():
                                console.print(Text("Connection with new session successful!", style=STYLE_SUCCESS_MSG))
                                break
                            else:
                                console.print(Text("Failed to connect even with new session. Retrying...", style=STYLE_ERROR_MSG))
                                await asyncio.sleep(0.0005)
                        else:
                            message = login_result.get('message', '').lower()
                            console.print(Text(f"Full re-login failed: {message}", style=STYLE_ERROR_MSG))
                            if "invalid" in message or "credentials" in message:
                                console.print(Text("Credentials might be incorrect. Please re-enter.", style=STYLE_WARNING_MSG))
                                get_user_credentials()
                            await asyncio.sleep(0.0005)
        console.print(Text("\nConnection is active. Waiting for Telegram signals...", style=STYLE_CONNECTION_INFO))
        monitor_task = asyncio.create_task(connection_monitor())
        g_account_context["connection_monitor_task"] = monitor_task
        try:
            await monitor_task
        except asyncio.CancelledError:
            pass
        await asyncio.sleep(0.0001)

def show_banner():
    try:
        os.system('cls' if os.name == 'nt' else 'clear')
        title_art = pyfiglet.figlet_format("Signal Trader", font="standard")
        gradient_colors = [Fore.CYAN, Fore.MAGENTA, Fore.YELLOW]
        colored_art = create_gradient_text(title_art, gradient_colors)
        text = Text.from_ansi(colored_art)
        
        panel = Panel(
            text,
            title="[bold]v2.0[/bold]",
            subtitle="[bold]Automated Trading Bot[/bold]",
            border_style="magenta",
            expand=False,
            padding=(1, 5)
        )
        console.print(panel)
        console.print(Text("─" * 80, style="magenta"))
        console.print(Text("📡 Advanced Telegram Signal Scheduler & Trader 📡", justify="center", style="yellow"))
        console.print(Text("─" * 80, style="magenta"))

    except Exception:
        console.print("[bold cyan]╔══════════════════════════════════════╗[/bold cyan]")
        console.print("[bold magenta]║          📡 SIGNAL TRADER 📡         ║[/bold magenta]")
        console.print("[bold yellow]║ Automated Telegram Signal Trading Bot  ║[/bold yellow]")
        console.print("[bold cyan]╚══════════════════════════════════════╝[/bold cyan]")

def create_gradient_text(text, colors):
    lines = text.split('\n')
    colored_lines = []
    for line in lines:
        if not line.strip():
            colored_lines.append(line)
            continue
        colored_line = ""
        length = len(line)
        for i, char in enumerate(line):
            position = i / max(1, length - 1)
            color_index = int(position * (len(colors) - 1))
            colored_line += f"{colors[color_index]}{char}"
        colored_lines.append(colored_line + ColoramaStyle.RESET_ALL)
    return '\n'.join(colored_lines)

class TelegramSignalListener:
    def __init__(self):
        self.config = {}
        self.telegram_client = None
        self.running = False
        self.print_lock = asyncio.Lock()
        self.signals_lock = asyncio.Lock()
        self.pending_signals = []
        self.TIMEZONE = ZoneInfo("Etc/GMT+3")

    FONT_MAP = {
        '𝙰': 'A', '𝙱': 'B', '𝙲': 'C', '𝙳': 'D', '𝙴': 'E', '𝙵': 'F', '𝙶': 'G', '𝙷': 'H', '𝙸': 'I', '𝙹': 'J',
        '𝙺': 'K', '𝙻': 'L', '𝙼': 'M', '𝙽': 'N', '𝙾': 'O', '𝙿': 'P', '𝚀': 'Q', '𝚁': 'R', '𝚂': 'S', '𝚃': 'T',
        '𝚄': 'U', '𝚅': 'V', '𝚆': 'W', '𝚇': 'X', '𝚈': 'Y', '𝚉': 'Z',
        '𝚊': 'a', '𝚋': 'b', '𝚌': 'c', '𝚍': 'd', '𝚎': 'e', '𝚏': 'f', '𝚐': 'g', '𝚑': 'h', '𝚒': 'i', '𝚓': 'j',
        '𝚔': 'k', '𝚕': 'l', '𝚖': 'm', '𝚗': 'n', '𝚘': 'o', '𝚙': 'p', '𝚚': 'q', '𝚛': 'r', '𝚜': 's', '𝚝': 't',
        '𝚞': 'u', '𝚟': 'v', '𝚠': 'w', '𝚡': 'x', '𝚢': 'y', '𝚣': 'z',
        '𝟶': '0', '𝟷': '1', '𝟸': '2', '𝟹': '3', '𝟺': '4', '𝟻': '5', '𝟼': '6', '𝟽': '7', '𝟾': '8', '𝟿': '9'
    }

    def normalize_text(self, text):
        return "".join(self.FONT_MAP.get(char, char) for char in text)

    async def safe_print(self, content, **kwargs):
        async with self.print_lock:
            console.print(content, **kwargs)

    def load_sessions(self):
        try:
            with open(SESSIONS_FILE, 'r') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {}

    def save_session(self, phone, session_string):
        sessions = self.load_sessions()
        sessions[phone] = session_string
        with open(SESSIONS_FILE, 'w') as f:
            json.dump(sessions, f, indent=4)

    def get_mobile_input(self, prompt, password=False):
        console.print(f"\n{prompt}", style=STYLE_INPUT)
        console.print("└─> ", style=STYLE_INFO, end="")
        return getpass.getpass("") if password else input("").strip()

    def handle_telegram_otp(self):
        console.print("\n📲 OTP VERIFICATION", style=STYLE_WARNING)
        console.print("Check your Telegram app for the verification code.", style=STYLE_INFO)
        return self.get_mobile_input("🔢 Enter the 5-digit verification code:")

    async def interactive_telegram_setup(self):
        console.print("\n📱 INTERACTIVE TELEGRAM SETUP", style=STYLE_HEADER)
        console.print("─" * 50, style=STYLE_INFO)
        try:
            phone = self.get_mobile_input("📞 Enter your Telegram phone number (e.g., +1234567890):")
            if not phone.startswith('+'): phone = '+' + phone
            api_id = int(self.get_mobile_input("🆔 Enter your Telegram API ID:"))
            api_hash = self.get_mobile_input("🔑 Enter your Telegram API Hash:")
        except ValueError:
            await self.safe_print("❌ Invalid input! API ID must be a number.", style=STYLE_ERROR)
            return False

        proxy_config = None
        use_proxy = self.get_mobile_input("🌐 Do you want to use a SOCKS5 proxy? (y/n) [default: n]:").lower()
        if use_proxy == 'y':
            proxy_string = self.get_mobile_input("🔗 Enter proxy string (host:port:user:pass or host:port):")
            parts = proxy_string.split(':')
            try:
                if len(parts) == 4:
                    host, port, user, password = parts
                    proxy_config = ("socks5", host, int(port), True, user, password)
                    await self.safe_print(f"✅ Proxy with authentication configured for {host}:{port}", style=STYLE_SUCCESS)
                elif len(parts) == 2:
                    host, port = parts
                    proxy_config = ("socks5", host, int(port))
                    await self.safe_print(f"✅ Proxy configured for {host}:{port}", style=STYLE_SUCCESS)
                else:
                    raise ValueError("Invalid format")
            except (ValueError, IndexError):
                await self.safe_print("❌ Invalid proxy format. Please use 'host:port' or 'host:port:username:password'.", style=STYLE_ERROR)
                return False

        await self.safe_print("\n🚀 Connecting to Telegram to fetch your chats...", style=STYLE_INFO)
        sessions = self.load_sessions()
        session_string = sessions.get(phone)
        client = TelegramClient(StringSession(session_string), api_id, api_hash, proxy=proxy_config)
        
        try:
            await client.connect()
            if not await client.is_user_authorized():
                await self.safe_print("User not authorized. Starting sign-in process...", style=STYLE_INFO)
                await client.send_code_request(phone)
                try:
                    await client.sign_in(phone, self.handle_telegram_otp())
                except SessionPasswordNeededError:
                    password = self.get_mobile_input(
                        "🔒 Two-Step Verification is enabled. Please enter your password:",
                        password=True
                    )
                    await client.sign_in(password=password)
            
            self.save_session(phone, client.session.save())
            await self.safe_print("✅ Login successful and session saved!", style=STYLE_SUCCESS)

        except Exception as e:
            await self.safe_print(f"❌ Telegram login failed: {e}", style=STYLE_ERROR)
            if client.is_connected(): await client.disconnect()
            return False

        await self.safe_print("\n🔍 Fetching your channels and groups...", style=STYLE_SUCCESS)
        available_chats = [{'id': d.id, 'title': d.title, 'type': 'Channel' if d.is_channel else 'Group'} for d in await client.get_dialogs() if d.is_channel or d.is_group]
        if not available_chats:
            await self.safe_print("❌ No channels or groups found.", style=STYLE_ERROR)
            await client.disconnect()
            return False

        table = Table(title="Your Available Chats", header_style="bold magenta")
        table.add_column("#", style="dim", width=4); table.add_column("Chat Title", style="cyan"); table.add_column("Type", style="yellow")
        for i, chat in enumerate(available_chats, 1): table.add_row(str(i), chat['title'], chat['type'])
        console.print(table)

        while True:
            selection_str = self.get_mobile_input("📈 Enter the numbers of the chats to monitor (comma-separated):")
            try:
                selected_indices = [int(s.strip()) - 1 for s in selection_str.split(',') if s.strip()]
                if all(0 <= i < len(available_chats) for i in selected_indices):
                    selected_chat_ids = [available_chats[i]['id'] for i in selected_indices]
                    selected_chat_titles = [available_chats[i]['title'] for i in selected_indices]
                    break
                else: await self.safe_print("❌ Invalid number detected.", style=STYLE_ERROR)
            except ValueError: await self.safe_print("❌ Invalid input. Please enter numbers only.", style=STYLE_ERROR)

        self.telegram_client = client
        self.config['chat_ids'] = selected_chat_ids
        await self.safe_print("\n✅ Configuration complete! You have selected:", style=STYLE_SUCCESS)
        for title in selected_chat_titles: await self.safe_print(f"   - {title}", style="green")
        return True

    def parse_asset(self, message):
        patterns = [
            r'💹\s*([A-Z]{6,}(?:_otc)?)',
            r'(?:Pair|Asset|Currency)\s*[:\->\s]+\s*([A-Z]{6,})',
            r'\b([A-Z]{6,}(?:_otc)?)\b',
            r'([A-Z]{3,})[/\-]([A-Z]{3,})'
        ]
        for pattern in patterns:
            match = re.search(pattern, message, re.IGNORECASE)
            if match:
                return f"{match.group(1).upper()}{match.group(2).upper()}" if len(match.groups()) == 2 else match.group(1).upper()
        return None

    def parse_direction(self, message):
        if re.search(r'🟢\s*CALL|\b(CALL|BUY|UP|COMPRA|SUBE)\b', message, re.IGNORECASE):
            return "CALL", "green"
        if re.search(r'🔴\s*PUT|\b(PUT|SELL|DOWN|VENDA|BAJA)\b', message, re.IGNORECASE):
            return "PUT", "red"
        return None, "white"

    def parse_duration(self, message):
        match = re.search(r'⏳\s*M(\d{1,2})', message, re.IGNORECASE)
        if match:
            return f"{match.group(1)} min"

        match = re.search(r'\bM(\d{1,2})\b', message, re.IGNORECASE)
        if match:
            return f"{match.group(1)} min"

        match = re.search(r'(\d{2,4})\s*(?:sec|s)', message, re.IGNORECASE)
        if match:
            return f"{match.group(1)} sec"
        return "N/A"

    def parse_entry_time(self, message):
        match = re.search(r'⏰\s*(\d{1,2}:\d{2}(?::\d{2})?)', message)
        if match:
            return match.group(1)

        match = re.search(r'\b(\d{1,2}:\d{2}(?::\d{2})?)\b', message)
        return match.group(1) if match else None

    async def handle_telegram_signal(self, event):
        message_content = event.raw_text
        normalized_message = self.normalize_text(message_content)

        asset = self.parse_asset(normalized_message)
        direction, color = self.parse_direction(normalized_message)
        if not all([asset, direction]):
            return

        duration = self.parse_duration(normalized_message)
        entry_time_str = self.parse_entry_time(normalized_message)
        now_local = datetime.now(self.TIMEZONE)
        execution_ts = 0

        if entry_time_str:
            try:
                parsed_time = dt_time.fromisoformat(entry_time_str)
                execution_dt = now_local.replace(hour=parsed_time.hour, minute=parsed_time.minute, second=parsed_time.second, microsecond=0)
                if execution_dt < now_local:
                    execution_dt += timedelta(days=1)
                execution_ts = execution_dt.timestamp()
            except ValueError:
                execution_ts = time.time()
        else:
            execution_ts = time.time()

        chat_info = await event.get_chat()
        signal_data = {
            "asset": asset, "direction": direction, "color": color, "duration": duration,
            "entry_time_str": datetime.fromtimestamp(execution_ts, self.TIMEZONE).strftime('%H:%M:%S'),
            "source": getattr(chat_info, 'title', f"ID: {event.chat_id}"),
            "execution_timestamp": execution_ts
        }

        async with self.signals_lock:
            self.pending_signals.append(signal_data)
        await self.display_scheduled_alert(signal_data)

    async def display_scheduled_alert(self, signal):
        panel = Panel(
            Text(f"  Asset:    {signal['asset']}\n"
                 f"  Action:   {signal['direction']}\n"
                 f"  Entry at: {signal['entry_time_str']}", justify="left"),
            title=f"[bold blue]📨 SIGNAL SCHEDULED 📨[/bold blue]",
            subtitle=f"From: {signal['source']}", border_style="blue"
        )
        await self.safe_print(panel)

    async def display_execution_alert(self, signal):
        output_text = Text()
        output_text.append(f"Source: ", style="bold yellow"); output_text.append(f"{signal['source']}\n\n")
        output_text.append(f"  Asset:    ", style="bold cyan"); output_text.append(f"{signal['asset']}\n", style="white")
        output_text.append(f"  Action:   ", style="bold cyan"); output_text.append(f"{signal['direction']}", style=f"bold {signal['color']}\n")
        output_text.append(f"  Duration: ", style="bold cyan"); output_text.append(f"{signal['duration']}\n", style="white")
        panel = Panel(output_text, title="[bold red]🚨 EXECUTE NOW! 🚨[/bold red]", border_style="bold red", expand=False, padding=(1, 2))
        await self.safe_print(panel)

    async def signal_processor(self):
        while self.running:
            try:
                signals_to_execute = []
                next_signal_ts = None

                async with self.signals_lock:
                    now_ts = time.time()
                    still_pending = []
                    for signal in self.pending_signals:
                        if signal['execution_timestamp'] <= now_ts:
                            signals_to_execute.append(signal)
                        else:
                            still_pending.append(signal)
                            if next_signal_ts is None or signal['execution_timestamp'] < next_signal_ts:
                                next_signal_ts = signal['execution_timestamp']
                    self.pending_signals = still_pending

                for signal in signals_to_execute:
                    await self.display_execution_alert(signal)

                    trade_duration_seconds = 60
                    duration_str = signal.get("duration", "60 sec")
                    if "min" in duration_str:
                        try:
                            minutes = int(re.search(r'\d+', duration_str).group())
                            trade_duration_seconds = minutes * 60
                        except: pass
                    elif "sec" in duration_str:
                        try:
                            trade_duration_seconds = int(re.search(r'\d+', duration_str).group())
                        except: pass

                    asset = signal['asset']
                    trade_amount_for_signal = TRADE_AMOUNT
                    if USE_MTG:
                        if mtg_state.get(asset, {}).get('level', 0) > 0:
                            await self.safe_print(f"⚠️ New signal for {asset} received, interrupting and resetting its active MTG cycle.", style=STYLE_WARNING)
                        mtg_state[asset] = {'level': 0}

                    asset_details = next((item for item in extract_and_process_instruments() if item['name'].lower() == asset.lower()), None)

                    if not asset_details or not asset_details.get('is_open'):
                        await self.safe_print(Text(f"SKIPPED: Asset '{asset}' is currently closed for trading.", style=STYLE_WARNING_MSG))
                        continue

                    payout = asset_details.get('payout_1m', 0)
                    if payout < MIN_PAYOUT:
                        await self.safe_print(Text(f"SKIPPED: Payout for '{asset}' ({payout}%) is below minimum ({MIN_PAYOUT}%).", style=STYLE_WARNING_MSG))
                        continue

                    await self.safe_print(f"Executing signal trade for {asset} with base amount: ${trade_amount_for_signal:.2f}", style=STYLE_INFO_MSG)

                    asyncio.create_task(buy_option_func(
                        trade_amount_for_signal,
                        SOURCE_ACCOUNT_TYPE,
                        signal['asset'],
                        signal['direction'].lower(),
                        trade_duration_seconds
                    ))

                sleep_duration = 1.0
                if next_signal_ts:
                    sleep_duration = min(sleep_duration, max(0, next_signal_ts - time.time()))

                await asyncio.sleep(sleep_duration)

            except Exception as e:
                await self.safe_print(f"❌ Error in signal processor: {e}", style=STYLE_ERROR)
                await asyncio.sleep(1.0)

    async def run(self):
        show_banner()
        self.running = True
        while self.running:
            if await self.interactive_telegram_setup():
                break
            else:
                await self.safe_print("\n❌ Telegram setup failed. Retrying after a short delay...", style=STYLE_ERROR)
                await asyncio.sleep(0.0005)

        if not self.running or not self.telegram_client:
            console.print("\n❌ Could not complete Telegram setup. Exiting listener task.", style=STYLE_ERROR)
            return

        processor_task = asyncio.create_task(self.signal_processor())
        self.telegram_client.add_event_handler(self.handle_telegram_signal, events.NewMessage(chats=self.config['chat_ids']))

        await self.safe_print("\n🎉 SETUP COMPLETE! The listener is now live.", style=STYLE_SUCCESS)
        await self.safe_print(f"📡 Monitoring {len(self.config['chat_ids'])} channel(s) for new signals...", style=STYLE_INFO)
        await self.safe_print("Press Ctrl+C to stop the listener.", style=STYLE_WARNING)

        try:
            await self.telegram_client.run_until_disconnected()
        finally:
            self.running = False
            processor_task.cancel()
            try: await processor_task
            except asyncio.CancelledError: pass

            if self.telegram_client and self.telegram_client.is_connected():
                await self.telegram_client.disconnect()
            await self.safe_print("\n👋 Listener stopped. See you next time!", style=STYLE_SUCCESS)

async def main():
    global g_event_loop
    show_banner()
    get_user_credentials()
    g_event_loop = asyncio.get_running_loop()
    listener = TelegramSignalListener()
    console.print("\n--- Starting Quotex and Telegram Clients Concurrently ---", style=STYLE_HEADER)
    await asyncio.gather(run_quotex_connection(), listener.run())
    console.print("\n--- Application Finished ---", style=STYLE_INFO_HEADER)

if __name__ == "__main__":
    try:
        if 'TERMUX_VERSION' in os.environ:
            console.print("📱 Termux environment detected - optimizing for mobile.", style=STYLE_INFO)
        asyncio.run(main())
    except KeyboardInterrupt:
        print(f"\n{Fore.YELLOW}🛑 Shutting down gracefully...{ColoramaStyle.RESET_ALL}")
    except Exception as e:
        console.print(f"\n❌ A critical error occurred: {e}", style=STYLE_ERROR)

